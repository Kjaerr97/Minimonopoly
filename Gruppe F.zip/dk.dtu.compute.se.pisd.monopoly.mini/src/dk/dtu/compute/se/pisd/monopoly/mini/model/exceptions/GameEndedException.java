package dk.dtu.compute.se.pisd.monopoly.mini.model.exceptions;

public class GameEndedException extends Exception {


    public GameEndedException(){
        super ("The game has ended.");
    }


/*
Kig op

Hvad skal denne exception bidrage med? I Play metoden er der allerede taget højde for scenariet med tilhørende prints.








 */



}
